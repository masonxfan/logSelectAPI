build the project by following command to generate runable jar file in /target dir
	mvn clean package

build Dockerfile:
	docker build -t springio/gs-spring-boot-docker .
run Dockerfile:
	docker run -p 8080:8080 springio/gs-spring-boot-docker

API call sample:
	curl --location --request POST 'http://localhost:8080/path' \
--header 'Content-Type: application/json' \
--data-raw '{
    "filename": "/c/Java/sampleInput/sample1.txt",
    "from": "2000-01-01T13:13:29Z",
    "to": "2000-01-03T03:32:09Z"
}'


Assumption:
	1. In dockerFile, config the access of input log directory as /c/Java/sampleInput
	2. API call body will contain filename as absolute directory : "/c/Java/sampleInput/sample1.txt"

Limitation:
	1. For packaging the code using Dockerfile, the packing is not working as expected. I tried "Run mvn clean package" in dockerfile by importing maven as build, but the packaging process didn't generate jar file as I planned.
	2. For using multi core processing the file, I find that processing the file using multi-thread did not improve the efficiency of the API. Reading the file into the buffer and chunk processing the buffer using multi thread still using linear time to read the big file. So I eventually choose the read-buffer approach to read the file by line, which have better behave than reading file chunck.
