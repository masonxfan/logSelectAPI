package com.logSelectAPI.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.logSelectAPI.model.LogSelectInput;
import com.logSelectAPI.model.LogSelectOutput;

public class LogSelectService {
	
	public List<LogSelectOutput> selectLog(LogSelectInput logSelectInput) throws FileNotFoundException, IOException{
		String filename = logSelectInput.getFilename();
		String from = logSelectInput.getFrom();
		String to = logSelectInput.getTo();
		List<LogSelectOutput> outputList = new ArrayList<LogSelectOutput>();
		try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
		    String line;
		    while ((line = br.readLine()) != null) {
		       String[] outputStr = line.split(" ");
		       if(isLater(outputStr[0], from)) continue;
		       if(isLater(to, outputStr[0])) break;
		       LogSelectOutput currentLine = new LogSelectOutput(outputStr[0], outputStr[1], outputStr[2]);
		       outputList.add(currentLine);
		    }
		}
		return outputList;
		
	}
	
	public boolean isLater(String former, String later) {
		for(int i = 0; i < former.length(); i++) {
			if(former.charAt(i) < later.charAt(i)) {
				return true;
			}else if(former.charAt(i) > later.charAt(i)) {
				return false;
			}
		}
		return false;
	}

}
