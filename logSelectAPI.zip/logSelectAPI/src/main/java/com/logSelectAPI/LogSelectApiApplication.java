package com.logSelectAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogSelectApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogSelectApiApplication.class, args);
	}

}
