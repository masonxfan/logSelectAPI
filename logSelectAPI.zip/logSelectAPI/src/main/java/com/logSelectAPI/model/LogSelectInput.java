package com.logSelectAPI.model;

public class LogSelectInput {
	private String filename;
	private String from;
	private String to;
	
	public LogSelectInput(String filename, String from, String to) {
		this.filename = filename;
		this.from = from;
		this.to = to;
	}

	public String getFilename() {
		return filename;
	}

	public String getFrom() {
		return from;
	}


	public String getTo() {
		return to;
	}
}
