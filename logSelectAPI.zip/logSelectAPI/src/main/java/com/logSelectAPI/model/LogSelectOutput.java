package com.logSelectAPI.model;

public class LogSelectOutput {
	private String eventTime;
	private String email;
	private String sessionId;
	
	public LogSelectOutput(String eventTime, String email, String sessionId) {
		this.eventTime = eventTime;
		this.email = email;
		this.sessionId = sessionId;
	}
	
	public String getEventTime() {
		return eventTime;
	}
	public String getEmail() {
		return email;
	}
	public String getSessionId() {
		return sessionId;
	}

	
}
