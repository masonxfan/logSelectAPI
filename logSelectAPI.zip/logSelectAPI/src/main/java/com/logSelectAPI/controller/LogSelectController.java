package com.logSelectAPI.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.logSelectAPI.model.LogSelectInput;
import com.logSelectAPI.model.LogSelectOutput;
import com.logSelectAPI.service.LogSelectService;

@RestController
public class LogSelectController {
	
	LogSelectService logSelectService = new LogSelectService();
	
	@RequestMapping(value = "/path", method = RequestMethod.POST)
	public ResponseEntity<List<LogSelectOutput>> greeting(@RequestBody LogSelectInput intput) {
		try {
			List<LogSelectOutput> logSelectOutput = logSelectService.selectLog(intput);
			return new ResponseEntity<>(logSelectOutput, HttpStatus.CREATED);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(null, HttpStatus.CREATED);
	}
}
