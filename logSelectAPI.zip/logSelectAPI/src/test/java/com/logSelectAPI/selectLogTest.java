package com.logSelectAPI;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.logSelectAPI.model.LogSelectInput;
import com.logSelectAPI.model.LogSelectOutput;
import com.logSelectAPI.service.LogSelectService;
import com.logSelectAPI.ExpectedOutPut;

class selectLogTest {

	@Test
	void selectLogTest() throws FileNotFoundException, IOException {
		LogSelectInput logSelectInput = new LogSelectInput("C:\\Script\\Java\\sampleInput\\sample1.txt", "2000-01-01T17:25:49Z", "2000-02-11T11:03:20Z");
		LogSelectService logSelectService = new LogSelectService();
		List<LogSelectOutput> res = logSelectService.selectLog(logSelectInput);
		String resStr = "";
		for(LogSelectOutput singleline : res) {
			resStr += singleline.getEventTime() + " " + singleline.getEmail() + " " + singleline.getSessionId() + "\r\n";
		}
		assertEquals(resStr, ExpectedOutPut.selectLogTestRes);
	}
	
	@Test
	void timeStampComparatorTest1() {
		LogSelectService logSelectService = new LogSelectService();
		boolean res = logSelectService.isLater("2000-01-01T17:25:49Z", "2000-02-11T11:03:20Z");
		assertEquals(res, true);
	}
	
	@Test
	void timeStampComparatorTest2() {
		LogSelectService logSelectService = new LogSelectService();
		boolean res = logSelectService.isLater("2000-02-11T11:03:20Z", "2000-01-01T17:25:49Z");
		assertEquals(res, false);
	}	
	
	@Test
	void timeStampComparatorTest3() {
		LogSelectService logSelectService = new LogSelectService();
		boolean res = logSelectService.isLater("2000-02-11T11:03:20Z", "2000-02-11T11:03:20Z");
		assertEquals(res, false);
	}
}
